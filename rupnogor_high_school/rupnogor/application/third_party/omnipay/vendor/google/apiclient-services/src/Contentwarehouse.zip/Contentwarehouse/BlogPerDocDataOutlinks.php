<?php
/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

namespace Google\Service\Contentwarehouse;

class BlogPerDocDataOutlinks extends \Google\Model
{
  /**
   * @var string
   */
  public $aggregationFp;
  /**
   * @var string
   */
  public $resolvedUrl;
  /**
   * @var int
   */
  public $siteSpamScore;
  /**
   * @var string
   */
  public $title;

  /**
   * @param string
   */
  public function setAggregationFp($aggregationFp)
  {
    $this->aggregationFp = $aggregationFp;
  }
  /**
   * @return string
   */
  public function getAggregationFp()
  {
    return $this->aggregationFp;
  }
  /**
   * @param string
   */
  public function setResolvedUrl($resolvedUrl)
  {
    $this->resolvedUrl = $resolvedUrl;
  }
  /**
   * @return string
   */
  public function getResolvedUrl()
  {
    return $this->resolvedUrl;
  }
  /**
   * @param int
   */
  public function setSiteSpamScore($siteSpamScore)
  {
    $this->siteSpamScore = $siteSpamScore;
  }
  /**
   * @return int
   */
  public function getSiteSpamScore()
  {
    return $this->siteSpamScore;
  }
  /**
   * @param string
   */
  public function setTitle($title)
  {
    $this->title = $title;
  }
  /**
   * @return string
   */
  public function getTitle()
  {
    return $this->title;
  }
}

// Adding a class alias for backwards compatibility with the previous class name.
class_alias(BlogPerDocDataOutlinks::class, 'Google_Service_Contentwarehouse_BlogPerDocDataOutlinks');
