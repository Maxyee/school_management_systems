<?php
/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

namespace Google\Service\Contentwarehouse;

class AssistantLogsMediaCapabilities extends \Google\Model
{
  /**
   * @var bool
   */
  public $canReceiveRemoteAction;
  /**
   * @var bool
   */
  public $hasScreen;

  /**
   * @param bool
   */
  public function setCanReceiveRemoteAction($canReceiveRemoteAction)
  {
    $this->canReceiveRemoteAction = $canReceiveRemoteAction;
  }
  /**
   * @return bool
   */
  public function getCanReceiveRemoteAction()
  {
    return $this->canReceiveRemoteAction;
  }
  /**
   * @param bool
   */
  public function setHasScreen($hasScreen)
  {
    $this->hasScreen = $hasScreen;
  }
  /**
   * @return bool
   */
  public function getHasScreen()
  {
    return $this->hasScreen;
  }
}

// Adding a class alias for backwards compatibility with the previous class name.
class_alias(AssistantLogsMediaCapabilities::class, 'Google_Service_Contentwarehouse_AssistantLogsMediaCapabilities');
